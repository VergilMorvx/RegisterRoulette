<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $degree = $_POST['degree'];

    // Generate 8-digit numeric code
    $code = sprintf('%08d', mt_rand(10000000, 99999999));

    $stmt = $pdo->prepare('INSERT INTO attendees (name, email, phone, degree, code) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$name, $email, $phone, $degree, $code]);

    // Use the same screen and container styling from other pages
    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Registration Success</title>
        <link rel='stylesheet' href='assets/style.css'>
    </head>
    <body>
        <div class='container'>
            <div class='screen'>
                <div class='screen__content'>
                    <h1 style='color: #fff; text-align: center;'>Thank You for Registering!</h1>
                    <h2 style='color: #fff; text-align: center;'>Your Code:</h2>
                    <h2 style='font-size: 36px; color: #fff; text-align: center;'><strong>$code</strong></h2>
                    <p style='color: #fff; text-align: center;'>That's your code. Screenshot it, you will need it for later.</p>
                </div>
            </div>
        </div>
    </body>
    </html>";
}
?>
