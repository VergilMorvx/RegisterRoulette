import sqlite3

db_path = 'db/attendees.db'  # Adjust the path if necessary

# Connect to the database
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Create the attendees table
cursor.execute('''
CREATE TABLE IF NOT EXISTS attendees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    degree TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL
);
''')

conn.commit()
conn.close()

print("Database setup completed.")
