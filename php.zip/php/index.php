<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conference Registration</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .sponsor-image {
            width: 150px;  /* Adjust size as needed */
            height: auto;  /* Maintain aspect ratio */
            position: absolute;
            top: 10px;    /* Distance from top */
            left: 10px;   /* Distance from left */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sponsor Image -->
        <img src="assets/deli.png" alt="Sponsor" class="sponsor-image">
        
        <div class="screen">
            <div class="screen__content">
                <h1 style="color: #fff;">Register for the Conference</h1>
                <form method="post" action="register.php">
                    <div class="form-group">
                        <label for="name" style="color: #fff;">Full Name:</label>
                        <input type="text" name="name" id="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email" style="color: #fff;">Email:</label>
                        <input type="email" name="email" id="email">
                    </div>
                    <div class="form-group">
                        <label for="phone" style="color: #fff;">Phone:</label>
                        <input type="text" name="phone" id="phone" required>
                    </div>
                    <div class="form-group">
                        <label for="degree" style="color: #fff;">Degree:</label>
                        <input type="text" name="degree" id="degree" required>
                    </div>
                    <button type="submit" class="button login__submit">Register</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
