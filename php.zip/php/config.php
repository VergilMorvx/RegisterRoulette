<?php
$host = 'localhost';
$db_name = 'attendees.db'; // Use the database name from your db folder
$db_path = __DIR__ . '/db/' . $db_name;

try {
    $pdo = new PDO('sqlite:' . $db_path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
?>
