<?php
include 'config.php';

$stmt = $pdo->query('SELECT name, code FROM attendees');
$attendees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Default number of winners
$winnersCount = isset($_POST['winners_count']) ? intval($_POST['winners_count']) : 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roulette</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .sponsor-image {
            width: 150px;  /* Adjust size as needed */
            height: auto;  /* Maintain aspect ratio */
            position: absolute;
            top: 10px;    /* Distance from top */
            left: 10px;   /* Distance from left */
        }
        .attendees-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
            padding: 20px;
        }
        .attendee {
            background: #fff;
            padding: 10px;
            text-align: center;
            border-radius: 10px;
            color: #4C489D;
            font-weight: bold;
            box-shadow: 0px 2px 2px #5C5696;
        }
        .highlighted {
            background-color: #C7C5F4;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sponsor Image -->
        <img src="assets/deli.png" alt="Sponsor" class="sponsor-image">

        <div class="screen">
            <div class="screen__content">
                <h1 style="color: #fff; text-align: center;">Roulette</h1>
                <form method="post" action="">
                    <label style="color: #fff;">Number of winners:</label>
                    <input type="number" name="winners_count" value="<?php echo $winnersCount; ?>" min="1" max="<?php echo count($attendees); ?>">
                    <button type="submit" class="button login__submit">Set Winners</button>
                </form>

                <div class="attendees-list" id="attendees-list">
                    <?php foreach ($attendees as $attendee): ?>
                        <div class="attendee"><?php echo htmlspecialchars($attendee['name']) . ' (' . htmlspecialchars($attendee['code']) . ')'; ?></div>
                    <?php endforeach; ?>
                </div>
                <button id="spin-roulette" class="button login__submit">Spin the Roulette</button>

                <h2 style="color: #fff; text-align: center; margin-top: 20px;">Winners:</h2>
                <div class="attendees-list" id="winners-list">
                    <!-- Winners will be displayed here -->
                </div>
            </div>
        </div>
    </div>

    <script>
        const attendees = <?php echo json_encode($attendees); ?>;
        const winnersCount = <?php echo $winnersCount; ?>;
        const attendeesList = document.getElementById('attendees-list');
        const winnersList = document.getElementById('winners-list');
        const spinButton = document.getElementById('spin-roulette');

        function shuffle(array) {
            for (let i = array.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [array[i], array[j]] = [array[j], array[i]];
            }
        }

        spinButton.addEventListener('click', function() {
            // Shuffle the attendees for randomness
            let shuffledAttendees = [...attendees];
            shuffle(shuffledAttendees);
            let winners = [];

            // Highlighting effect variables
            let index = 0;
            const attendeesDivs = attendeesList.getElementsByClassName('attendee');
            const highlightIntervalTime = 100; // Speed of highlighting in ms
            const highlightDuration = 3000; // Time the highlight effect will last (3 seconds)

            // Highlighting effect
            const highlightInterval = setInterval(() => {
                // Remove the highlight from all attendees
                for (let div of attendeesDivs) {
                    div.classList.remove('highlighted');
                }
                // Highlight the current attendee
                if (index < attendeesDivs.length) {
                    attendeesDivs[index].classList.add('highlighted');
                }
                // Move to the next attendee (loop back to the beginning if necessary)
                index = (index + 1) % attendeesDivs.length;
            }, highlightIntervalTime);

            // After the highlight duration, stop the highlight and select winners
            setTimeout(() => {
                clearInterval(highlightInterval);

                // Randomly select winners
                winners = shuffledAttendees.slice(0, winnersCount);

                // Display winners in stacked format
                winnersList.innerHTML = '';
                winners.forEach(winner => {
                    let winnerDiv = document.createElement('div');
                    winnerDiv.className = 'attendee highlighted';
                    winnerDiv.textContent = `${winner.name} (${winner.code})`;
                    winnersList.appendChild(winnerDiv);
                });
            }, highlightDuration);
        });
    </script>
</body>
</html>
