from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
import sqlite3
import secrets
import random

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Initialize the database and create the table if it doesn't exist
def init_db():
    conn = sqlite3.connect('static/info/attendees.db')
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS attendees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        degree TEXT NOT NULL,  -- Added degree field
        code TEXT UNIQUE NOT NULL
    )''')
    conn.commit()
    conn.close()

# Generate a unique 8-digit number code
def generate_unique_code():
    while True:
        code = ''.join(random.choices('0123456789', k=8))  # Generate only digits
        conn = sqlite3.connect('static/info/attendees.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM attendees WHERE code = ?", (code,))
        if cursor.fetchone()[0] == 0:
            conn.close()
            return code
        conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    degree = request.form['degree']  # Capture the degree
    code = generate_unique_code()
    
    conn = sqlite3.connect('static/info/attendees.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO attendees (name, email, phone, degree, code) VALUES (?, ?, ?, ?, ?)",
                   (name, email, phone, degree, code))
    conn.commit()
    conn.close()

    # Use flash to send the unique code to the index page
    flash(f'Thank you for registering! Your unique code is: {code}')
    
    return redirect(url_for('index'))

@app.route('/roulette')
def roulette():
    return render_template('roulette.html')

@app.route('/get_attendees', methods=['GET'])
def get_attendees():
    conn = sqlite3.connect('static/info/attendees.db')
    cursor = conn.cursor()
    cursor.execute("SELECT name, code FROM attendees")
    attendees = cursor.fetchall()
    conn.close()
    return jsonify(attendees)

if __name__ == '__main__':
    init_db()  # Initialize the DB if it doesn't exist
    app.run(host='0.0.0.0', port=80, debug=True)  # Enable external access
