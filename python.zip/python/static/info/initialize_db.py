import sqlite3

conn = sqlite3.connect('./static/info/attendees.db')

# Create a table if it doesn't exist
conn.execute('''CREATE TABLE IF NOT EXISTS attendees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    full_name TEXT,
                    email TEXT,
                    phone TEXT,
                    unique_code TEXT)''')
                    
print("Database initialized.")

conn.close()
